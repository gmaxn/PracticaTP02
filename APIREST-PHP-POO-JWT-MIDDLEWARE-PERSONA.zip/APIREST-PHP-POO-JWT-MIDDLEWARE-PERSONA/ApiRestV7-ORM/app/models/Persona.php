<?php  
namespace App\Models;
 
class Persona extends \Illuminate\Database\Eloquent\Model {  
  
}

?>