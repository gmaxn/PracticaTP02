# 1. CREATE DATABASE

	CREATE DATABASE utn CHARACTER SET UTF8 collate utf8_spanish_ci

# 2. DEFINE TABLE

 /*
	Tabla Persona

	PersonId
	FirstName
	LastName
	Email
	User
	Pass
*/

# 3. CREATE TABLE

CREATE TABLE Persons ( 
PersonID int NOT NULL AUTO_INCREMENT,
FirstName varchar(255),
LastName varchar(255) NOT NULL,
Email varchar(255) NOT NULL,
User varchar(255) NOT NULL,
Pass varchar(255) NOT NULL,
PRIMARY KEY (PersonID)
);

# 4. INSERT SOME VALUES

INSERT INTO table_name (FirstName, LastName, Email, User, Pass)
VALUES ('Maximiliano', 'Güelpa', 'mguelpa@gmail.com', 'mguelpa', 'mguelpa'), 
('Gandalf', 'The Grey', 'gthegrey@hotmail.com', 'gthegrey', 'gthegrey'), 
('Bilbo', 'Baggins', 'bbaggins@outlook.com', 'bbaggins', 'bbagins')